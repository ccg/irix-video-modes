#include <X11/Xlib.h>
#include <X11/extensions/XSGIvc.h>

main(int argc, char *argv[]) {
  int i, got = 0;
  char **combs, *monitor;
  Display *dpy = XOpenDisplay(NULL);
  XSGIvcVideoFormatInfo *vci, *vp;
  static XSGIvcVideoFormatInfo vcpattern;

  XSGIvcQueryMonitorName(dpy, 0, 0, &monitor);
  fprintf(stderr, "Monitor name: %s\n", monitor);

  vci = XSGIvcListVideoFormats(dpy,
              0/* screen */,
              0/* channel */,
              &vcpattern,
              0L/*querymask*/,
              0/* matchMonitor */,
              999/*maxformats*/,
              &got);

  fprintf(stderr, "Got %d formats:\n", got);
  for(i = 0; i < got; i++) {
    vp = &vci[i];
    printf("%d: '%s' %dx%d (total %dx%d) %gHz %gSwapHz fmt %x fields %d\n",
	i, vp->name, vp->width, vp->height, vp->totalWidth, vp->totalHeight,
	vp->verticalRetraceRate, vp->swapbufferRate,
	vp->formatFlags, vp->fieldCount);
  }
}
